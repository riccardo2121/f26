import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';
import compression from 'vite-plugin-compression';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    react(),
    compression({ algorithm: 'brotliCompress', ext: '.br', threshold: 1024 }),
    compression({ algorithm: 'gzip', ext: '.gz', threshold: 1024 }),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['logo.png'],
      manifest: {
        name: "I Giarratano Parrucchieri",
        short_name: "Giarratano",
        description: "Taglio e colore su misura a Sant'Ambrogio di Torino",
        theme_color: '#f7f4ee',
        background_color: '#f7f4ee',
        display: 'standalone',
        icons: [
          { src: 'logo.png', sizes: '192x192', type: 'image/png' },
          { src: 'logo.png', sizes: '512x512', type: 'image/png' }
        ]
      }
    }),
  ],
  server: {
    host: true, // Ascolta su tutte le interfacce per accesso da rete/tunnel
    hmr: {
      protocol: 'wss',
      clientPort: 443,
    },
  },
  optimizeDeps: {
    exclude: ['lucide-react'],
  },
});
