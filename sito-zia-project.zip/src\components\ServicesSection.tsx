import { services } from "../content";
import { Pill } from "./UI";
import { ChevronRight } from "lucide-react";

export function ServicesSection() {
  return (
    <section id="servizi" className="reveal mx-auto max-w-[1400px] px-4 py-12 md:py-24">
      <div className="text-center max-w-3xl mx-auto mb-6 md:mb-16">
        <p className="text-[10px] uppercase tracking-[.25em] font-bold text-[var(--accent)] mb-4">Esperienze Esclusive</p>
        <h2 className="text-3xl md:text-6xl font-serif font-medium leading-tight">Cura & Dedizione <br/><span className="italic text-[var(--accent)]">per i tuoi capelli</span></h2>
        <div className="flex md:hidden items-center justify-center gap-2 mt-3 text-[10px] uppercase tracking-[.25em] font-bold opacity-60">
          <span>Scorri</span>
          <ChevronRight size={14} />
        </div>
      </div>

      <div className="relative">
        <div className="md:hidden edge-fade edge-fade-left"></div>
        <div className="md:hidden edge-fade edge-fade-right"></div>
        <div className="flex overflow-x-auto snap-x snap-mandatory md:grid md:grid-cols-3 gap-2 md:gap-8 pb-2 md:pb-0 px-2 md:px-0 scrollbar-hide w-full">
          {services.map((s) => (
          <article key={s.title} className="snap-center shrink-0 w-[88vw] md:w-auto group p-4 md:p-8 rounded-[1.7rem] card-premium hover:-translate-y-1 transition-all duration-300 touch-bounce">
            <Pill>{s.tag}</Pill>
            <h3 className="mt-3 md:mt-6 text-base md:text-2xl font-serif font-medium">{s.title}</h3>
            <p className="mt-2 md:mt-4 text-sm md:text-base opacity-70 leading-relaxed font-light">{s.desc}</p>
          </article>
          ))}
        </div>
      </div>
    </section>
  );
}
