import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { HeroSection } from "../components/HeroSection";
import { ServicesSection } from "../components/ServicesSection";
import { GallerySection } from "../components/GallerySection";
import { TeamSection } from "../components/TeamSection";
import { PricesSection } from "../components/PricesSection";
import { HowItWorksSection } from "../components/HowItWorksSection";

export const Home = () => {
  const { hash } = useLocation();

  useEffect(() => {
    if (hash) {
      const element = document.getElementById(hash.replace("#", ""));
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    }
  }, [hash]);

  return (
    <>
      <HeroSection />

      {/* STRIP */}
      <div className="border-y border-[var(--line)] bg-[var(--surface)]/60 backdrop-blur-sm overflow-hidden flex">
        <div className="flex animate-scroll whitespace-nowrap py-6">
          <div className="flex gap-x-12 text-[10px] uppercase tracking-[.25em] font-bold opacity-70 px-6">
             <span>Taglio donna</span><span>Piega</span><span>Colore</span><span>Balayage</span><span>Trattamenti</span><span>Sposa</span>
          </div>
          <div className="flex gap-x-12 text-[10px] uppercase tracking-[.25em] font-bold opacity-70 px-6">
             <span>Taglio donna</span><span>Piega</span><span>Colore</span><span>Balayage</span><span>Trattamenti</span><span>Sposa</span>
          </div>
          <div className="flex gap-x-12 text-[10px] uppercase tracking-[.25em] font-bold opacity-70 px-6">
             <span>Taglio donna</span><span>Piega</span><span>Colore</span><span>Balayage</span><span>Trattamenti</span><span>Sposa</span>
          </div>
          <div className="flex gap-x-12 text-[10px] uppercase tracking-[.25em] font-bold opacity-70 px-6">
             <span>Taglio donna</span><span>Piega</span><span>Colore</span><span>Balayage</span><span>Trattamenti</span><span>Sposa</span>
          </div>
        </div>
      </div>

      <ServicesSection />

      <GallerySection />

      <TeamSection />

      <HowItWorksSection />
      <PricesSection />
    </>
  );
};

 
