import { team } from "../content";
import { ChevronRight } from "lucide-react";

export function TeamSection() {
  return (
    <section id="chi-siamo" className="reveal mx-auto max-w-6xl px-4 py-12 md:py-32 relative">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-[var(--accent)] rounded-full mix-blend-multiply filter blur-[120px] opacity-5 pointer-events-none"></div>
      
      <div className="text-center max-w-3xl mx-auto mb-6 md:mb-20 relative z-10">
        <p className="text-[10px] uppercase tracking-[.25em] font-bold text-[var(--accent)] mb-4">Chi Siamo</p>
        <h2 className="text-3xl md:text-6xl font-serif font-medium leading-tight">Il nostro <br/><span className="italic text-[var(--accent)]">team</span></h2>
        <div className="flex md:hidden items-center justify-center gap-2 mt-3 text-[10px] uppercase tracking-[.25em] font-bold opacity-60">
          <span>Scorri</span>
          <ChevronRight size={14} />
        </div>
      </div>

      <div className="relative">
        <div className="md:hidden edge-fade edge-fade-left"></div>
        <div className="md:hidden edge-fade edge-fade-right"></div>
        <div className="flex overflow-x-auto snap-x snap-mandatory md:grid md:grid-cols-3 gap-2 md:gap-8 pb-2 md:pb-0 px-2 md:px-0 scrollbar-hide w-full">
        {team.map((t) => (
          <div key={t.name} className="snap-center shrink-0 w-[88vw] md:w-auto card-premium p-4 md:p-10 rounded-[1.7rem] transition-all duration-300 group hover:-translate-y-1 touch-bounce">
            <div className="text-sm uppercase tracking-[.2em] font-bold text-[var(--ink)] mb-1.5 group-hover:text-[var(--accent)] transition-colors">{t.name}</div>
            <div className="text-[10px] uppercase tracking-wider opacity-60 mb-4 md:mb-6">{t.role}</div>
            <p className="text-sm md:text-lg opacity-80 font-light leading-relaxed">
              {t.text}
            </p>
          </div>
        ))}
        </div>
      </div>
    </section>
  );
}
