import { galleryImages, salon } from "../content";
import { Button, Pill } from "./UI";
import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

export function GallerySection() {
  const categories = useMemo(() => {
    const set = new Set(galleryImages.map(g => g.category));
    return ["Tutte", ...Array.from(set)];
  }, []);
  const [active, setActive] = useState<string>("Tutte");
  const filtered = active === "Tutte" ? galleryImages : galleryImages.filter(g => g.category === active);

  return (
    <section id="gallery" className="reveal mx-auto max-w-6xl px-4 py-12 md:py-32">
      <div className="text-center max-w-3xl mx-auto mb-10 md:mb-16">
        <p className="text-[10px] uppercase tracking-[.25em] font-bold text-[var(--accent)] mb-4">Portfolio</p>
        <h2 className="text-3xl md:text-6xl font-serif font-medium leading-tight mb-8">Le nostre <br/><span className="text-[var(--accent)]">creazioni</span></h2>
        <div className="flex justify-center">
          <Button href={salon.instagram} variant="outline" className="py-4 px-8 w-full md:w-auto">Seguici su Instagram</Button>
        </div>
      </div>
      <div className="flex flex-wrap items-center justify-center gap-2 md:gap-3 mb-6">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setActive(cat)}
            className={`px-3 py-1 rounded-full border ${active === cat ? "bg-[var(--ink)] text-[var(--paper)] border-[var(--ink)]" : "border-[var(--line)]"} text-sm`}
          >
            {cat}
          </button>
        ))}
      </div>
      <MobileGallerySlider images={filtered} />
      <div className="hidden md:grid mt-8 md:mt-12 grid-cols-3 gap-4 md:gap-6 md:auto-rows-[300px]">
        {filtered.map((img, i) => (
          <div 
            key={img.jpeg} 
            className={`relative overflow-hidden rounded-[2rem] border border-[var(--line)] bg-[var(--line)] group ${
              i % 3 === 0 ? "md:col-span-2" : ""
            }`}
          >
            <picture>
              {img.avif && (
                <source type="image/avif" srcSet={img.avif} />
              )}
              {img.webp && (
                <source type="image/webp" srcSet={img.webp} />
              )}
              <img
                src={img.jpeg}
                alt={img.alt ?? `Lavoro ${i + 1}`}
                loading="lazy"
                decoding="async"
                width={img.width}
                height={img.height}
                className="h-full w-full object-cover transition-transform duration-700 md:group-hover:scale-110"
              />
            </picture>
            <div className="absolute top-4 left-4">
              <Pill>{img.category}</Pill>
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-8">
              <p className="text-[var(--paper)] font-serif text-2xl italic transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500 delay-100">Creazione Esclusiva</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function MobileGallerySlider({ images }: { images: typeof galleryImages }) {
  const [current, setCurrent] = useState(0);
  const prev = () => setCurrent((c) => (c - 1 + images.length) % images.length);
  const next = () => setCurrent((c) => (c + 1) % images.length);

  return (
    <div className="block md:hidden mt-6 relative">
      <div className="relative overflow-hidden rounded-[1.6rem] border border-[var(--line)] bg-[var(--surface)]">
        <picture>
          {images[current]?.avif && (
            <source type="image/avif" srcSet={images[current].avif as string} />
          )}
          {images[current]?.webp && (
            <source type="image/webp" srcSet={images[current].webp as string} />
          )}
          <img
            src={images[current]?.jpeg ?? ""}
            alt={images[current]?.alt ?? `Lavoro ${current + 1}`}
            loading="lazy"
            decoding="async"
            width={640}
            height={280}
            className="w-full h-[280px] object-cover"
          />
        </picture>
        <button
          aria-label="Immagine precedente"
          onClick={prev}
          className="absolute left-3 top-1/2 -translate-y-1/2 bg-[var(--accent)] text-[var(--paper)] p-3 rounded-full ring-2 ring-[var(--accent)]/40 shadow-xl hover:brightness-110 transition"
        >
          <ChevronLeft size={28} />
        </button>
        <button
          aria-label="Immagine successiva"
          onClick={next}
          className="absolute right-3 top-1/2 -translate-y-1/2 bg-[var(--accent)] text-[var(--paper)] p-3 rounded-full ring-2 ring-[var(--accent)]/40 shadow-xl hover:brightness-110 transition"
        >
          <ChevronRight size={28} />
        </button>
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-2 px-3 py-1 rounded-full bg-[var(--paper)]/80 backdrop-blur border border-[var(--line)] text-[10px] uppercase tracking-[.2em] font-bold">
          <span>{current + 1}</span>
          <span className="opacity-60">/</span>
          <span>{images.length}</span>
        </div>
      </div>
    </div>
  );
}
