import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Scissors, Menu, X, MapPin, Image, Tag, Users, Star, Phone, MessageCircle } from "lucide-react";
import { salon } from "../content";

export const Layout = ({ children }: { children: React.ReactNode }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState<string>("");
  useEffect(() => {
    const els = document.querySelectorAll<HTMLElement>(".reveal");
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("is-visible");
          }
        });
      },
      { rootMargin: "0px 0px -10% 0px", threshold: 0.1 }
    );
    els.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const ids = ["servizi", "gallery", "prezzi", "chi-siamo"];
    const sections = ids
      .map((id) => document.getElementById(id))
      .filter(Boolean) as HTMLElement[];
    if (!sections.length) return;
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActiveSection((e.target as HTMLElement).id);
        });
      },
      { rootMargin: "-40% 0px -40% 0px", threshold: 0.1 }
    );
    sections.forEach((s) => obs.observe(s));
    return () => obs.disconnect();
  }, []);

  return (
    <div className="min-h-screen bg-[var(--paper)] text-[var(--ink)]">
      <a href="#contenuto" className="skip-link">Vai al contenuto</a>
       

      {/* Top bar */}
      <div className="hidden md:block border-b border-[var(--line)]">
        <div className="mx-auto max-w-[1400px] px-4 py-2 text-[12px] font-medium flex flex-wrap items-center justify-between gap-3 opacity-80">
          <div className="flex items-center gap-3">
            <span>{salon.city}</span>
            <span className="opacity-50">•</span>
            <span>{salon.address}</span>
            <span className="opacity-50">•</span>
            <span>{salon.hours.split("\n")[0]}</span>
            <span className="opacity-50">•</span>
            <a className="hover:text-[var(--accent)] transition-colors" href={`tel:${salon.phone.replace(/\s+/g,"")}`}>
              {salon.phone}
            </a>
          </div>
          <div className="flex items-center gap-3">
            <a className="hover:text-[var(--accent)] transition-colors" href={salon.whatsapp}>
              WhatsApp
            </a>
            <span className="opacity-50">•</span>
            <a className="hover:text-[var(--accent)] transition-colors" href={salon.maps} target="_blank" rel="noreferrer noopener" aria-label="Apri su Google Maps">
              Apri su Google Maps
            </a>
          </div>
        </div>
      </div>

      {/* Header sticky */}
      <header className="sticky top-0 z-50 header-glass safe-top border-b border-[var(--line)]">
        <div className="mx-auto max-w-[1400px] px-4 py-3 flex items-center justify-between gap-3">
          <Link to="/" className="flex items-center gap-3 flex-1 min-w-0" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <img src="/logo.png" alt={salon.name} className="h-10 w-auto object-contain rounded-lg border border-[var(--line)] shadow-sm" />
            <div className="leading-tight">
              <div className="font-semibold text-sm whitespace-nowrap">{salon.name}</div>
              <div className="text-[12px] opacity-60 hidden sm:block truncate">Parrucchiere • {salon.city}</div>
            </div>
          </Link>

          <nav className="hidden md:flex items-center">
            <div className="nav-wrap">
              <Link className={`nav-link ${activeSection==="servizi" ? "nav-link-active" : ""}`} to="/#servizi"><Scissors size={16} /> Servizi</Link>
              <Link className={`nav-link ${activeSection==="gallery" ? "nav-link-active" : ""}`} to="/#gallery"><Image size={16} /> Galleria</Link>
              <Link className={`nav-link ${activeSection==="prezzi" ? "nav-link-active" : ""}`} to="/#prezzi"><Tag size={16} /> Prezzi</Link>
              <Link className={`nav-link ${activeSection==="chi-siamo" ? "nav-link-active" : ""}`} to="/#chi-siamo"><Users size={16} /> Chi siamo</Link>
              <Link className="nav-link" to="/recensioni"><Star size={16} /> Recensioni</Link>
              <Link className="nav-link" to="/contatti"><Phone size={16} /> Contatti</Link>
            </div>
          </nav>

          <div className="flex items-center gap-2">
            {/* Map Button */}
            <a 
              href={salon.maps} 
              target="_blank" 
              rel="noreferrer noopener"
              className="hidden md:inline-flex items-center gap-2 rounded-full bg-[var(--accent)] text-[var(--paper)] px-4 py-2 text-sm font-semibold shadow-lg ring-2 ring-[var(--accent)]/30 hover:brightness-110 transition animate-pulse-ring"
              title="Dove Siamo"
              aria-label="Apri mappa"
            >
              <MapPin size={22} />
              <span className="inline">Mappa</span>
            </a>

            {/* Hamburger Button */}
            <button 
              className="md:hidden p-2 rounded-full border border-[var(--line)] bg-[var(--paper)] hover:text-[var(--accent)] transition-colors z-50 relative"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>

            
          </div>
        </div>
      </header>

      

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-[var(--paper)] flex flex-col items-center justify-center md:hidden animate-fade-in px-6 text-center">
          <button 
            className="absolute top-6 right-6 p-2 hover:text-[var(--accent)] transition-colors"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <X size={32} />
          </button>
          
          <div className="mb-10">
            <img src="/logo.png" alt={salon.name} className="h-16 w-auto object-contain mx-auto mb-2" />
            <div className="font-semibold text-sm">{salon.name}</div>
          </div>

          <nav className="flex flex-col items-center gap-4 text-2xl font-medium w-full max-w-sm">
            <Link onClick={() => setIsMobileMenuOpen(false)} className={`nav-mobile-link ${activeSection==="servizi" ? "nav-link-active" : ""}`} to="/#servizi"><Scissors size={20} /> Servizi</Link>
            <Link onClick={() => setIsMobileMenuOpen(false)} className={`nav-mobile-link ${activeSection==="gallery" ? "nav-link-active" : ""}`} to="/#gallery"><Image size={20} /> Galleria</Link>
            <Link onClick={() => setIsMobileMenuOpen(false)} className={`nav-mobile-link ${activeSection==="prezzi" ? "nav-link-active" : ""}`} to="/#prezzi"><Tag size={20} /> Prezzi</Link>
            <Link onClick={() => setIsMobileMenuOpen(false)} className="nav-mobile-link" to="/recensioni"><Star size={20} /> Recensioni</Link>
            <Link onClick={() => setIsMobileMenuOpen(false)} className="nav-mobile-link" to="/contatti"><Phone size={20} /> Contatti</Link>
          </nav>

          <div className="mt-12 flex flex-col gap-4 w-full max-w-xs">
            <a
              href={salon.whatsapp}
              className="flex items-center justify-center px-5 py-3 rounded-full border border-[var(--ink)] text-sm font-semibold hover:bg-[var(--ink)] hover:text-[var(--paper)] transition"
            >
              WhatsApp
            </a>
            <a
              href={`tel:${salon.phone}`}
              onClick={() => setIsMobileMenuOpen(false)}
              className="flex items-center justify-center px-5 py-3 rounded-full bg-[var(--ink)] text-[var(--paper)] text-sm font-semibold hover:opacity-90 transition"
            >
              Prenota Ora
            </a>
          </div>
        </div>
      )}

      {/* Decorative Badge */}
      <div className="fixed top-28 right-6 z-40 hidden lg:flex items-center justify-center pointer-events-none mix-blend-multiply opacity-20 grayscale hover:grayscale-0 hover:opacity-100 transition-all duration-700">
        <div className="relative w-32 h-32 animate-[spin_12s_linear_infinite]">
           <svg viewBox="0 0 100 100" className="w-full h-full overflow-visible">
              <defs>
                 <path id="circle" d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0" />
              </defs>
              <text fontSize="10" fontWeight="bold" letterSpacing="3" fill="currentColor">
                 <textPath xlinkHref="#circle">
                    I GIARRATANO • PARRUCCHIERI •
                 </textPath>
              </text>
           </svg>
        </div>
        <Scissors className="absolute w-8 h-8 text-[var(--accent)]" strokeWidth={1.5} />
      </div>

      <main id="contenuto">
        {children}
      </main>

      {/* Sticky CTA (mobile) */}
      <div className="md:hidden fixed bottom-0 inset-x-0 z-[60] safe-area-bottom">
        <div className="mx-auto max-w-[1400px] px-3 pb-[calc(6px+env(safe-area-inset-bottom))]">
          <div className="rounded-full bg-[var(--paper)]/95 backdrop-blur-md border border-[var(--line)] shadow-2xl flex items-center p-2">
            <a
              href={salon.whatsapp}
              className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3 rounded-full bg-[#25D366] text-white text-sm font-semibold shadow-md ring-1 ring-[#25D366]/30 hover:brightness-110 transition"
              aria-label="WhatsApp"
            >
              <MessageCircle size={18} />
              WhatsApp
            </a>
          </div>
        </div>
      </div>

      {/* FOOTER */}
      <footer className="border-t border-[var(--line)]">
        <div className="mx-auto max-w-[1400px] px-4 py-8 text-xs flex flex-col md:flex-row gap-3 md:items-center md:justify-between">
          <div className="uppercase tracking-[.2em] font-semibold">
            © {new Date().getFullYear()} {salon.name}
          </div>
          <div className="flex flex-wrap gap-x-4 gap-y-2 opacity-70">
            <a className="hover:opacity-100" href={salon.instagram} target="_blank" rel="noreferrer noopener">Instagram</a>
            <a className="hover:opacity-100" href="#top">Torna su</a>
            <a className="hover:opacity-100" href={salon.privacy}>Privacy</a>
          </div>
        </div>
      </footer>
    </div>
  );
};
