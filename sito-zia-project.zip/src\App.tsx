import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Layout } from "./components/Layout";
import { Home } from "./pages/Home";
import { Reviews } from "./pages/Reviews";
import { Contact } from "./pages/Contact";

export default function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/recensioni" element={<Reviews />} />
          <Route path="/contatti" element={<Contact />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}
