export const salon = {
  name: "I Giarratano Parrucchieri",
  city: "Sant'Ambrogio di Torino",
  address: "Corso Moncenisio 56/A, 10057",
  phone: "011 939319",
  whatsapp: "https://wa.me/39011939319",
  booking: "/contatti",
  maps: "https://www.google.com/maps/search/?api=1&query=I+Giarratano+Parrucchieri+Sant+Ambrogio+Torino",
  instagram: "https://www.instagram.com/igiarratanoparrucchieri?igsh=NXVqMGt3eXM1eTI5",
  hours: "Mar-Mer: 09:00–12:30, 14:30–18:30\nGio: 09:00–18:30\nVen-Sab: 08:30–18:30\nDom-Lun: Chiuso",
  privacy: "/privacy",
};

export const services = [
  { tag: "Donna", title: "Taglio Sartoriale & Styling", desc: "Tagli personalizzati che valorizzano il tuo viso. Piega e finish per un look perfetto." },
  { tag: "Color", title: "Colorazioni & Schiariture D'Autore", desc: "Dalle tinte organiche al Balayage. Tecniche moderne per colori luminosi e naturali." },
  { tag: "Care", title: "Rituali di Benessere & Cura", desc: "Ricostruzione, idratazione e cura della cute. Il benessere dei tuoi capelli al primo posto." },
  { tag: "Uomo", title: "Barber & Grooming Uomo", desc: "Stile classico o moderno. Precisione e cura dei dettagli per il look maschile." },
  { tag: "Sposa", title: "Sposa & Grandi Eventi", desc: "Il look perfetto per il tuo giorno speciale. Consulenza e prove incluse." },
  { tag: "Prodotti", title: "Home Care & Prodotti", desc: "I migliori prodotti professionali per curare i tuoi capelli anche a casa." },
];

export const pricesWoman: Array<[string, string]> = [
  ["Piega", "€[XX]"],
  ["Taglio + Piega", "€[XX]"],
  ["Colore", "€[XX]"],
  ["Balayage", "€[XX]"],
];

export const pricesMen: Array<[string, string]> = [
  ["Taglio", "€[XX]"],
  ["Barba / Rifinitura", "€[XX]"],
  ["Taglio + Barba", "€[XX]"],
  ["Trattamento cute", "€[XX]"],
];

export const gallery = [
  "/creazione.jpg",
  "/creazione2.jpg",
  "/creazione3.jpg",
];

export const reviews = [
  { name: "Maria Simonetta", text: "Oggi per la prima volta mi sono recata in questo centro. Sono stata accolta in maniera professionale ma allo stesso tempo in maniera molto dolce.", stars: 5 },
  { name: "Mariateresa Pedicini", text: "Ottima esperienza. Il personale è accogliente e gentilissimo, sono attenti ai dettagli e c'è estrema professionalità nel taglio.", stars: 5 },
  { name: "Chiara Gonnon", text: "Non posso che fare solo complimenti a questo salone. Persone fantastiche che ti coccolano da quando metti piede all'interno fino a quando esci.", stars: 5 },
  { name: "Ginevra", text: "Super soddisfatta! Mi sono trovata benissimo e grazie alla loro professionalità hanno realizzato esattamente quello che desideravo.", stars: 5 },
  { name: "Simone Borrini", text: "Che dire di Giarratano.. i migliori parrucchieri della Valle.", stars: 5 },
  { name: "Fabrizio A", text: "Gentilezza e professionalità... con competenza sanno trovare la giusta soluzione, per realizzare le richieste del cliente contribuendo con buoni consigli.", stars: 5 },
];

export const team = [
  { name: "Gianni Giarratano", role: "Hair Stylist", text: "Esperienza pluriennale e attenzione ai dettagli. Specialista nel taglio maschile e femminile." },
  { name: "Marianna Giarratano", role: "Technical Director", text: "Maestra del colore e della cura del capello. Crea sfumature uniche per ogni cliente." },
  { name: "Mimma", role: "Senior Stylist", text: "Professionalità e cortesia. Esperta nel comprendere e realizzare i desideri di ogni cliente." },
];
