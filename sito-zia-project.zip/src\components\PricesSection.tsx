import { pricesWoman, pricesMen } from "../content";

export function PricesSection() {
  return (
    <section id="prezzi" className="reveal relative bg-[var(--surface)] py-12 md:py-24 overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-[var(--line)] to-transparent opacity-50"></div>
      
      <div className="mx-auto max-w-[1400px] px-4 relative z-10">
        <div className="flex flex-col md:flex-row gap-12 md:gap-16 items-center md:items-start">
          <div className="md:w-1/3 md:sticky md:top-32 text-center md:text-left">
            <p className="text-[10px] uppercase tracking-[.25em] font-bold text-[var(--accent)] mb-4">Trasparenza</p>
            <h2 className="text-2xl md:text-6xl font-serif font-medium mb-6 md:mb-8 leading-tight">Il Valore <br/><span className="italic text-[var(--accent)]">del tuo Stile</span></h2>
            <p className="opacity-80 text-base md:text-lg leading-relaxed mb-10 font-light">
              Un investimento sulla tua bellezza. Ogni servizio include una consulenza personalizzata e l'utilizzo di prodotti premium specifici per le tue esigenze.
            </p>
            
          </div>

          <div className="md:w-2/3 grid sm:grid-cols-2 gap-4 md:gap-6 w-full">
            <div className="card-premium p-5 md:p-10 rounded-[2rem] transition-all duration-300 hover:-translate-y-1">
              <h3 className="text-xs uppercase tracking-[.2em] font-bold text-[var(--accent)] mb-8">Donna</h3>
              <ul className="space-y-4 text-base">
                {pricesWoman.map((item) => (
                  <li key={item.name} className="flex justify-between items-baseline gap-4 border-b border-[var(--line)] pb-3 last:border-0 group cursor-default">
                    <div className="flex flex-col">
                      <span className="font-medium opacity-90 group-hover:text-[var(--accent)] transition-colors">{item.name}</span>
                      {item.duration && <span className="text-sm opacity-60">Durata: {item.duration}</span>}
                    </div>
                    <span className="font-serif font-bold text-xl">da €{item.from}</span>
                  </li>
                ))}
              </ul>
              <p className="mt-6 text-sm opacity-70">I prezzi sono indicativi: il costo finale dipende da lunghezza e tecnica. Confermiamo sempre il prezzo prima di iniziare.</p>
            </div>

            <div className="card-premium p-5 md:p-10 rounded-[2rem] transition-all duration-300 hover:-translate-y-1">
              <h3 className="text-xs uppercase tracking-[.2em] font-bold text-[var(--accent)] mb-8">Uomo</h3>
              <ul className="space-y-4 text-base">
                {pricesMen.map((item) => (
                  <li key={item.name} className="flex justify-between items-baseline gap-4 border-b border-[var(--line)] pb-3 last:border-0 group cursor-default">
                    <div className="flex flex-col">
                      <span className="font-medium opacity-90 group-hover:text-[var(--accent)] transition-colors">{item.name}</span>
                      {item.duration && <span className="text-sm opacity-60">Durata: {item.duration}</span>}
                    </div>
                    <span className="font-serif font-bold text-xl">da €{item.from}</span>
                  </li>
                ))}
              </ul>
              <p className="mt-6 text-sm opacity-70">I prezzi sono indicativi: il costo finale dipende da lunghezza e tecnica. Confermiamo sempre il prezzo prima di iniziare.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
