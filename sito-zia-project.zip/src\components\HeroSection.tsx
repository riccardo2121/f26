import { salon } from "../content";
import { MessageCircle, Star } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "./UI";

export function HeroSection() {
  const [hover, setHover] = useState(0);
  const [selected, setSelected] = useState(0);
  const [parallax, setParallax] = useState(0);
  useEffect(() => {
    const mq = window.matchMedia("(max-width: 768px)");
    if (!mq.matches) return;
    const onScroll = () => {
      const y = window.scrollY || 0;
      const val = Math.max(0, Math.min(20, y * 0.05));
      setParallax(val);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  const reviewUrl = salon.placeId
    ? `https://search.google.com/local/writereview?hl=it&placeid=${salon.placeId}`
    : `https://www.google.com/search?q=${encodeURIComponent(`${salon.name} ${salon.city} recensioni Google`)}&hl=it`;
  return (
    <section className="relative pt-24 pb-12 md:pt-48 md:pb-24 px-4 overflow-hidden">
      <div className="mx-auto max-w-[1400px] relative z-10">
        <div className="grid lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-5 relative z-10 order-2 md:order-2 lg:order-1">
            <div className="inline-block px-4 py-1.5 rounded-full bg-[var(--surface)] border border-[var(--line)] shadow-sm mb-8">
              <span className="text-[12px] font-semibold text-[var(--accent)]">Colore & Taglio su misura</span>
            </div>
            <h1 className="text-3xl md:text-6xl lg:text-7xl font-serif font-medium leading-[1.12] mb-3 md:mb-6">
              Taglio e colore su misura<br />
              <span className="italic text-[var(--accent)] relative inline-block">a {salon.city}</span>
            </h1>
            <p className="text-sm md:text-xl font-light opacity-85 mb-4 md:mb-6 max-w-md leading-relaxed">
              Consulenza personalizzata, prodotti professionali e risultati curati.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button href={salon.whatsapp} variant="solid" className="px-6 py-3 md:px-10 md:py-5 text-base md:text-lg font-semibold">
                <MessageCircle className="w-6 h-6 mr-3" />
                <span>Prenota ora</span>
              </Button>
              <Button href={`tel:${salon.phone.replace(/\s+/g,"")}`} variant="outline" className="px-6 py-3 md:px-8 md:py-4">Chiama ora</Button>
            </div>
            <div className="mt-8 text-sm opacity-80">
              {typeof salon.rating === "number" ? `${salon.rating.toFixed(1)}★ su Google` : "Recensioni su Google"}
              {typeof salon.customers === "number" && salon.customers > 0 ? ` • +${salon.customers} clienti soddisfatti` : ""}
            </div>
            <div className="mt-12 flex items-center gap-4">
              <div className="w-14 h-14 rounded-full border border-[var(--line)] bg-[var(--paper)] p-2 flex items-center justify-center shadow-sm">
                <img src="/logo.png" alt="Reviews" className="w-full h-full object-contain" />
              </div>
              <div className="p-2 border-l border-[var(--line)]">
                <div className="text-[var(--accent)] font-serif font-bold text-2xl italic leading-none flex items-center gap-1">
                  4.6 <span className="text-xl">★</span>
                </div>
                <div className="opacity-60 text-[10px] uppercase tracking-wider font-bold mt-1">Recensioni</div>
              </div>
            </div>
            <div className="mt-6">
              <div className="text-xs uppercase tracking-[.2em] font-bold opacity-70 mb-2">Lascia una recensione</div>
              <div className="flex items-center gap-3">
                <div className="inline-flex items-center">
                  {[1,2,3,4,5].map((n) => (
                    <button
                      key={n}
                      onMouseEnter={() => setHover(n)}
                      onMouseLeave={() => setHover(0)}
                      onClick={() => { setSelected(n); window.open(reviewUrl, "_blank"); }}
                      aria-label={`${n} stelle`}
                      className="p-1"
                    >
                      <Star
                        size={22}
                        className={(hover >= n || selected >= n) ? "text-[var(--accent)]" : "text-[var(--ink)]/30"}
                        fill={(hover >= n || selected >= n) ? "currentColor" : "none"}
                      />
                    </button>
                  ))}
                </div>
                <a
                  href={reviewUrl}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="text-xs font-semibold underline opacity-80 hover:opacity-100 transition"
                >
                  Scrivi su Google
                </a>
              </div>
            </div>
          </div>
          <div className="lg:col-span-7 relative overflow-hidden rounded-[2.5rem] card-premium group rotate-1 md:hover:rotate-0 transition-transform duration-700 order-1 md:order-1 lg:order-2 mb-8 lg:mb-0">
            {salon.heroAvif || salon.heroWebp ? (
              <picture>
                {salon.heroAvif && (
                  <source
                    type="image/avif"
                    srcSet={`${salon.heroAvif} 1600w`}
                    sizes="(max-width: 768px) 100vw, 800px"
                  />
                )}
                {salon.heroWebp && (
                  <source
                    type="image/webp"
                    srcSet={`${salon.heroWebp} 1600w`}
                    sizes="(max-width: 768px) 100vw, 800px"
                  />
                )}
                <img
                  src={salon.heroJpeg ?? ""}
                  alt={`Salone ${salon.name}`}
                  loading="eager"
                  decoding="async"
                  width={1600}
                  height={600}
                  className="h-[460px] md:h-[600px] w-full object-cover object-[50%_42%] transition-transform duration-700 md:group-hover:scale-105"
                  style={{ transform: `translateY(${parallax}px)` }}
                />
              </picture>
            ) : (
              <img
                src={salon.heroJpeg ?? ""}
                srcSet="
                  https://images.pexels.com/photos/3993449/pexels-photo-3993449.jpeg?auto=compress&cs=tinysrgb&w=480 480w,
                  https://images.pexels.com/photos/3993449/pexels-photo-3993449.jpeg?auto=compress&cs=tinysrgb&w=800 800w,
                  https://images.pexels.com/photos/3993449/pexels-photo-3993449.jpeg?auto=compress&cs=tinysrgb&w=1200 1200w,
                  https://images.pexels.com/photos/3993449/pexels-photo-3993449.jpeg?auto=compress&cs=tinysrgb&w=1600 1600w
                "
                sizes="(max-width: 768px) 100vw, 800px"
                alt={`Salone ${salon.name}`}
                loading="eager"
                decoding="async"
                width={1600}
                height={600}
                className="h-[460px] md:h-[600px] w-full object-cover object-[50%_42%] transition-transform duration-700 md:group-hover:scale-105"
                style={{ transform: `translateY(${parallax}px)` }}
              />
            )}
            <div className="pointer-events-none absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-[var(--paper)] to-transparent opacity-80"></div>
            <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-[var(--accent)] rounded-full mix-blend-multiply filter blur-xl opacity-60"></div>
          </div>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 w-full overflow-hidden leading-[0]">
        <svg className="relative w-full h-[60px]" viewBox="0 0 1200 120" preserveAspectRatio="none">
          <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z" fill="var(--paper)" fillOpacity="0.8"></path>
        </svg>
      </div>
    </section>
  );
}
