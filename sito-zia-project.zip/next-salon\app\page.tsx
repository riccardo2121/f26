import { salon } from "@/content";

export default function Home() {
  return (
    <main className="min-h-screen px-4 py-16">
      <h1 className="text-4xl font-serif font-medium leading-tight">
        Parrucchiere a {salon.city} – {salon.name}
      </h1>
      <p className="mt-4 text-lg opacity-80">
        Consulenza personalizzata, tagli e colore su misura. Prenota su WhatsApp. {salon.address}
      </p>
      <div className="mt-8 flex gap-4">
        <a href={salon.whatsapp} className="px-6 py-3 rounded-full bg-black text-white text-sm uppercase tracking-widest">WhatsApp</a>
        <a href={`tel:${salon.phone}`} className="px-6 py-3 rounded-full border border-black text-sm uppercase tracking-widest">Prenota</a>
      </div>
    </main>
  );
}
